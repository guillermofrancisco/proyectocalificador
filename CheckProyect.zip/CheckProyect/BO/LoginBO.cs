﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheckProyect.BO
{
    public class LoginBO
    {

       public int id;
	public string usuario1;
public string	password1;
public string correo;
public string tipousuario;
public string Nombre;
    }
}