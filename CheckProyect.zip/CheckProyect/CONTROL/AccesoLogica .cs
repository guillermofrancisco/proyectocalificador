﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CheckProyect.DAO;
using System.IO;
using System.Data;

namespace CheckProyect.CONTROL
{
    public class AccesoLogica
    {
        public static Boolean insertarPDF(string pdfnombre, string pdfruta, string droplist, string nombre, string repre, string correo, string url, string comentario, string documento, int idusuario, string pdfnombre2, string pdfruta2)
        {
            FileStream fs = new FileStream(pdfruta, FileMode.Open, FileAccess.Read);
            FileStream fs2 = new FileStream(pdfruta2, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            BinaryReader br2 = new BinaryReader(fs2);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            Byte[] bytes2 = br2.ReadBytes((Int32)fs2.Length);
            br.Close();
            br2.Close();
            fs.Close();
            fs2.Close();
            return AccesoDatos.insertPDF(pdfnombre, bytes, droplist, nombre, repre, correo, url, comentario, documento, idusuario, pdfnombre2, bytes2);
        }

        public static DataTable descargarPDF(int id)
        {
            return AccesoDatos.selectPDF(id);
        }
    }
}