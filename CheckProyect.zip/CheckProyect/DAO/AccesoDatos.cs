﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace CheckProyect.DAO
{
    public class AccesoDatos
    {
        public static Boolean insertPDF(string nombrePDF, Byte[] PDFbytes, string droplist, string nombre, string repre, string correo, string url, string comentario, string documento, int idusuario, string nombrePDF2, Byte[] PDFbytes2)
        {
            SqlCommand _comando = MetodosDatos.crearComando();
            _comando.CommandText = "INSERT INTO Proyecto (Documento, Tipo, pdf1, Nombre, Correo, link, Comentario, IdCategoria, IdUsuario, Documento2, Tipo2, pdf2)" + "VALUES(@NombrePDF,@TipoPDF,@DatosPDF,@Repre,@Correo, @Link, @Comentario, @Categoria, @idusuario,@NombrePDF2,@TipoPDF2,@DatosPDF2 )";
            _comando.Parameters.Add("@NombrePDF", SqlDbType.VarChar).Value = nombrePDF;
            _comando.Parameters.Add("@TipoPDF", SqlDbType.VarChar).Value = "application/pdf";
            _comando.Parameters.Add("@DatosPDF", SqlDbType.Binary).Value = PDFbytes;
            _comando.Parameters.Add("@Repre", SqlDbType.VarChar).Value = nombre;
            _comando.Parameters.Add("@Correo", SqlDbType.VarChar).Value = correo;
            _comando.Parameters.Add("@Link", SqlDbType.VarChar).Value = url;
            _comando.Parameters.Add("@Comentario", SqlDbType.VarChar).Value = comentario;
            _comando.Parameters.Add("@Categoria", SqlDbType.VarChar).Value = droplist;
            _comando.Parameters.Add("@idusuario", SqlDbType.Int).Value = idusuario;
            _comando.Parameters.Add("@NombrePDF2", SqlDbType.VarChar).Value = nombrePDF2;
            _comando.Parameters.Add("@TipoPDF2", SqlDbType.VarChar).Value = "application/pdf";
            _comando.Parameters.Add("@DatosPDF2", SqlDbType.Binary).Value = PDFbytes2;

            return MetodosDatos.ejecutarInsert(_comando);
        }

        public static DataTable selectPDF(int id)
        {
            SqlCommand _comando = MetodosDatos.crearComando();
            _comando.CommandText = "SELECT * FROM Proyecto where IdProyecto=" + id;
            return MetodosDatos.ejecutarSelect(_comando);
        }
    }
}