﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CheckProyect.BO;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CheckProyect.DAO
{
    public class AsignarDAO
    {
        public int AsignarProyectoEmprendimientoAdd(int IdProyecto,int IdEvaluador)
        {
            Conexion MiConexion = new Conexion();
            DataSet dt = new DataSet();
            int num = 0;
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "AsignarProyectoEmprendimiento";
                cmd.Parameters.Add(new SqlParameter("@IdProyecto", IdProyecto));
                cmd.Parameters.Add(new SqlParameter("@IdValuador", IdEvaluador));
               

                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dt, "consultarusdf");
                return 1;

            }
            catch (Exception e)
            {
                return 0;
            }

            return num;

        }
        public int AsignarProyectoProyectoAdd(int IdProyecto, int IdEvaluador)
        {
            Conexion MiConexion = new Conexion();
            DataSet dt = new DataSet();
            int num = 0;
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "AsignarProyectoProyecto";
                cmd.Parameters.Add(new SqlParameter("@IdProyecto", IdProyecto));
                cmd.Parameters.Add(new SqlParameter("@IdValuador", IdEvaluador));


                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dt, "consultarusdf");
                return 1;

            }
            catch (Exception e)
            {
                return 0;
            }

            return num;

        }




        public int AsignarProyectoIdeaAdd(int IdProyecto, int IdEvaluador)
        {
            Conexion MiConexion = new Conexion();
            DataSet dt = new DataSet();
            int num = 0;
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "AsignarProyectoIdea";
                cmd.Parameters.Add(new SqlParameter("@IdProyecto", IdProyecto));
                cmd.Parameters.Add(new SqlParameter("@IdValuador", IdEvaluador));


                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dt, "consultarusdf");
                return 1;

            }
            catch (Exception e)
            {
                return 0;
            }

            return num;

        }



        public int CalificaProyectoIdeaAdd(int IdProyecto, int Escalabilidad,int PotencialImpacto,int ResolucionNecesidad,int ConstruccionAlianza,int GeneracionEmpleo,int Innovacion,int Total,int IdValuador)
        {
            Conexion MiConexion = new Conexion();
            DataSet dt = new DataSet();
            int num = 0;
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());
//                @IdProyecto int,
//@Escalabilidad int,
//@PotencialImpacto int,
//@ResolucionNecesidad int,
//@ConstruccionAlianza int,
//@GeneracionEmpleo int,
//@Innovacion int ,
//@Total int,
//@IdValuador int
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "CalificarIdea";
                cmd.Parameters.Add(new SqlParameter("@IdProyecto", IdProyecto));
                cmd.Parameters.Add(new SqlParameter("@Escalabilidad", Escalabilidad));
                cmd.Parameters.Add(new SqlParameter("@PotencialImpacto", PotencialImpacto));
                cmd.Parameters.Add(new SqlParameter("@ResolucionNecesidad", ResolucionNecesidad));
                cmd.Parameters.Add(new SqlParameter("@ConstruccionAlianza", ConstruccionAlianza));
                cmd.Parameters.Add(new SqlParameter("@GeneracionEmpleo", GeneracionEmpleo));
                cmd.Parameters.Add(new SqlParameter("@Innovacion", Innovacion));
                cmd.Parameters.Add(new SqlParameter("@Total", Total));
                cmd.Parameters.Add(new SqlParameter("@IdValuador", IdValuador));


                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dt, "consultarusdf");
                return 1;

            }
            catch (Exception e)
            {
                return 0;
            }

            return num;

        }




    }
}