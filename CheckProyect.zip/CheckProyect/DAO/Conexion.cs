﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using System.Configuration;

namespace CheckProyect.DAO
{
    public class Conexion
    {
        public Conexion()
        {
        }
        public string GetConex()
        {
        //https://codeshare.io/WsYZO?

            string strConex = ConfigurationManager.ConnectionStrings["samu"].ConnectionString;
            if (object.ReferenceEquals(strConex, string.Empty))
            {
                return string.Empty;
            }
            else
            {
                return strConex;
            }
        }
    }
    
}