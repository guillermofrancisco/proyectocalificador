﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheckProyect.DAO
{
    public class Configuracion
    {
        static string cadenaConexion = "Server=HP-PC\\SQLEXPRESS; Database=Calificador; User ID=sa;Password=sonda";
        public static string CadenaConexion
        {
            get { return cadenaConexion; }
        }
    }
}