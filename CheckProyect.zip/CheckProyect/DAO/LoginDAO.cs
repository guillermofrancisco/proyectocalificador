﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CheckProyect.BO;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CheckProyect.DAO
{
    public class LoginDAO
    {
        public DataSet Login(LoginBO user)
        {
            Conexion MiConexion = new Conexion();

            DataSet dts = new DataSet();
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UsuarioLogin";
                cmd.Parameters.Add(new SqlParameter("@usuario", user.usuario1));
                cmd.Parameters.Add(new SqlParameter("@password", user.password1));
                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dts, "usuario");
            }
            catch
            {

            }

            return dts;

        }


        public DataSet ValuadoresGetAll()
        {
            Conexion MiConexion = new Conexion();

            DataSet dts = new DataSet();
            try
            {
                Conexion miConexion = new Conexion();



                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ValuadoresGetAll";

                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dts, "consultarv");
            }
            catch (Exception e)
            {

            }

            return dts;

        }

        public int UsuarioAdd(LoginBO user)
        {
            Conexion MiConexion = new Conexion();
            DataSet dt = new DataSet();
            int num = 0;
            try
            {
                Conexion miConexion = new Conexion();

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());
              
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UsuarioAdd";
                cmd.Parameters.Add(new SqlParameter("@Usuario", user.usuario1));
                cmd.Parameters.Add(new SqlParameter("@Pass", user.password1));
                cmd.Parameters.Add(new SqlParameter("@Correo", user.correo));
                cmd.Parameters.Add(new SqlParameter("@Nombre", user.Nombre));
                cmd.Parameters.Add(new SqlParameter("@TipoUsuario", 3));
              
                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dt, "consultarusdf");
                return 1;

            }
            catch (Exception e)
            {
                return 0;
            }

            return num;

        }



    }
}