﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CheckProyect.BO;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CheckProyect.DAO
{
    public class ProyectoDAO
    {

        public DataSet ProyectoGetAll()
        {
            Conexion MiConexion = new Conexion();

            DataSet dts = new DataSet();
            try
            {
                Conexion miConexion = new Conexion();

              

                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ProyectoGetAll";

                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dts, "consultar");
            }
            catch (Exception e)
            {

            }

            return dts;

        }

        public DataSet ProyectoGetAll2(int idevaluador)
        {
            Conexion MiConexion = new Conexion();

            DataSet dts = new DataSet();
            try
            {
                Conexion miConexion = new Conexion();



                SqlConnection cnx; cnx = new SqlConnection(miConexion.GetConex());

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ProyectoGetAll2";
                cmd.Parameters.Add(new SqlParameter("@idevaluador", idevaluador));

                SqlDataAdapter miada;
                miada = new SqlDataAdapter(cmd);
                miada.Fill(dts, "consultar");
            }
            catch (Exception e)
            {

            }

            return dts;

        }

    }
}