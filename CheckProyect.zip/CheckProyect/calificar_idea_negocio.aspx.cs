﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CheckProyect.BO;
using CheckProyect.DAO;


namespace CheckProyect
{
    public partial class calificar_idea_negocio : System.Web.UI.Page
    {
        int Idval;
        int IdPro;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Idval = Convert.ToInt32(Request.QueryString["idevaluador"].ToString().Trim());
                IdPro = Convert.ToInt32(Request.QueryString["id"].ToString().Trim());
            }
            catch { }
        }

        protected void cb15inn_CheckedChanged(object sender, EventArgs e)
        {
            if (cb12inn.Checked == true)
            {
                Response.Write("<script>window.alert('checado');</script>");
            }
            else {
                Response.Write("<script>window.alert('no checado');</script>");
            }
            
        }
        public int escalabilidad()
        {
            int num = 0;

            if (cb3esc.Checked == true)
            {

                num = 3;
            }
            if (cb6esc.Checked == true)
            {
                num = 6;
            }
            if (cb9esc.Checked == true)
            {
                num = 9;
            }
            if (cb12esc.Checked == true)
            {
                num =12;
            }
            if (cb15esc.Checked == true)
            {
                num = 15;
            }

            return num;
        
        }
        public int resolucion()
        {
            int num = 0;

            if (cb4res.Checked == true)
            {

                num = 4;
            }
            if (cb8res.Checked == true)
            {
                num = 8;
            }
            if (cb12res.Checked == true)
            {
                num = 12;
            }
            if (cb16res.Checked == true)
            {
                num = 16;
            }
            if (cb20res.Checked == true)
            {
                num = 20;
            }

            return num;

        }



        public int potencial()
        {
            int num = 0;

            if (cb4pon.Checked == true)
            {

                num = 4;
            }
            if (cb8pon.Checked == true)
            {
                num = 8;
            }
            if (cb12pon.Checked == true)
            {
                num = 12;
            }
            if (cb16pon.Checked == true)
            {
                num = 16;
            }
            if (cb20pon.Checked == true)
            {
                num = 20;
            }

            return num;

        }
         public int construccion()
        {
            int num = 0;

            if (cb3con.Checked == true)
            {
                num = 3;

            }
            if (cb6con.Checked == true)
            {
                num =6;
            }
            if (cb9con.Checked == true)
            {
                num = 9;
            }
            if (cb12con.Checked == true)
            {
                num =12;
            }
            if (cb15con.Checked == true)
            {
                num = 15;
            }


            return num;

        }
         public int generacion()
         {
             int num = 0;

             if (cb3gen.Checked == true)
             {
                 num = 3;

             }
             if (cb6gen.Checked == true)
             {
                 num = 6;
             }
             if (cb9gen.Checked == true)
             {
                 num = 9;
             }
             if (cb12gen.Checked == true)
             {
                 num = 12;
             }
             if (cb15gen.Checked == true)
             {
                 num = 15;
             }


             return num;

         }
         public int inovacion()
         {
             int num = 0;

             if (cb3inn.Checked == true)
             {
                 num = 3;

             }
             if (cb6inn.Checked == true)
             {
                 num = 6;
             }
             if (cb9inn.Checked == true)
             {
                 num = 9;
             }
             if (cb12inn.Checked == true)
             {
                 num = 12;
             }
             if (cb15inn.Checked == true)
             {
                 num = 15;
             }


             return num;

         }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id = 0;
                int total = 0;
                int valuador = 2;

                total = escalabilidad() + potencial() + resolucion() + construccion() + generacion() + inovacion();
                AsignarDAO Asign = new AsignarDAO();
                Asign.CalificaProyectoIdeaAdd(IdPro, escalabilidad(), potencial(), resolucion(), construccion(), generacion(), inovacion(), total, Idval);

            }
            catch { }

            


            
        }

        protected void Btncalcu_Click(object sender, EventArgs e)
        {
            try
            {
                int total = 0;
                total = escalabilidad() + potencial() + resolucion() + construccion() + generacion() + inovacion();

                Response.Write("<script>window.alert('EL total es " + total.ToString() + "');</script>");
            }
            catch { }
        }
    }
}