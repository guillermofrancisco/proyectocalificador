﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CheckProyect.BO;
using CheckProyect.DAO;

namespace CheckProyect
{
    public partial class listado1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Listardatos();
            }
        }

        private void Listardatos()
        {
            try
            {
                
                ProyectoDAO userCtrl = new ProyectoDAO();

                DataSet dts = userCtrl.ProyectoGetAll();
                GridFabricantes.DataSource = dts.Tables[0];
                GridFabricantes.DataBind();

            }
            catch (Exception e) {
                Response.Write("<script>window.alert('"+e+"');</script>");
            }


        }

        protected void GridFabricantes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "btnEditar")
                {

                    int index = Convert.ToInt32(e.CommandArgument);
                    string d = GridFabricantes.Rows[index].Cells[4].Text.ToString();
                    string id = GridFabricantes.DataKeys[index].Value.ToString();

                    //string usuario1 = GridView1.DataKeys[index].Value.ToString();
                    //string password1 = GridView1.DataKeys[index].Value.ToString();
                    //string correo = GridView1.DataKeys[index].Value.ToString();



                    Response.Redirect("listado_admin.aspx?id=" + id + "&categi=" + d);
                }
            }
            catch { }
        }

        protected void GridFabricantes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}