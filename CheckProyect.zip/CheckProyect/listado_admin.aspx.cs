﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CheckProyect.BO;
using CheckProyect.DAO;

namespace CheckProyect
{
    public partial class listado_admin : System.Web.UI.Page
    {
        public string cat="";
        public string id = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                 cat = Request.QueryString["categi"].ToString().Trim();
                id = Request.QueryString["id"].ToString().Trim();
                Response.Write("<script>window.alert('" + id + cat + "');</script>");
                if (!Page.IsPostBack)
                {
                    Listardatos();
                }
            }
            catch { }
        }
        private void Listardatos()
        {
            try
            {

                LoginDAO userCtrl = new LoginDAO();

                DataSet dts = userCtrl.ValuadoresGetAll();
                GridView1.DataSource = dts.Tables[0];
                GridView1.DataBind();

            }
            catch (Exception e)
            {
                Response.Write("<script>window.alert('" + e + "');</script>");
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                AsignarDAO prodao = new AsignarDAO();

                string va = "";
                foreach (GridViewRow row in GridView1.Rows)
                {
                    CheckBox check = (CheckBox)row.FindControl("CheckBox3");
                    va = va + check.Checked.ToString();
                    if (cat.Trim() == "Idea de negocio")
                    {
                        if (check.Checked.ToString() == "True")
                        {
                            prodao.AsignarProyectoIdeaAdd(Convert.ToInt32(id), Convert.ToInt32(row.Cells[1].Text));
                        }

                    }
                    if (cat.Trim() == "Proyecto Emprendido")
                    {
                        if (check.Checked.ToString() == "True")
                        {
                            prodao.AsignarProyectoIdeaAdd(Convert.ToInt32(id), Convert.ToInt32(row.Cells[1].Text));
                        }
                    }
                    if (cat.Trim() == "Emprendimiento Social")
                    {
                        if (check.Checked.ToString() == "True")
                        {
                            prodao.AsignarProyectoIdeaAdd(Convert.ToInt32(id), Convert.ToInt32(row.Cells[1].Text));
                        }
                    }

                    //  he.usuariomodifi(Convert.ToInt32(row.Cells[2].Text), check.Checked.ToString(), "", "");
                }
                Response.Write("<script>window.alert('" + va + "');</script>");
            }
            catch { 
            }
        }
    }
}