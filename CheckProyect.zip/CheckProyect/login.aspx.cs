﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using CheckProyect.BO;
using CheckProyect.DAO;


namespace CheckProyect
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            LoginBO user = new LoginBO();
            LoginDAO userCtrl = new LoginDAO();
            user.usuario1 = TextBox1.Text;
            user.password1 = TextBox2.Text;
            try
            {
                DataSet dts = userCtrl.Login(user);

                if (dts.Tables.Count > 0)
                {
                    string tipusu = dts.Tables[0].Rows[0][4].ToString();
                    string idusu = dts.Tables[0].Rows[0][0].ToString();
                    string nombreUsu = dts.Tables[0].Rows[0][5].ToString();
                    if (tipusu.Trim() != "")
                    {
                        if (Session["s_tipousuario"] == null)
                        {
                            Session["s_tipousuario"] = tipusu;
                        }
                        if (Session["s_idusuario"] == null)
                        {
                            Session["s_idusuario"] = idusu;
                        }
                        if (Session["s_Nomusuario"] == null)
                        {
                            Session["s_Nomusuario"] = nombreUsu;
                        }
                        if (tipusu == "1") { 
                        Response.Redirect("listado1.aspx?");
                        }
                        if (tipusu == "2") {

                            Response.Redirect("Inicio2.aspx");
                        }

                      

                        if (tipusu == "3") {
                            Response.Redirect("subir_proyecto.aspx");
                        }
                        //Response.Redirect("home.aspx?");
            }
                    Response.Write("<script>window.alert('" + idusu + "');</script>");
                }
                else
                {
                    Response.Write("<script>window.alert('usuario o contraseña incorrecto');</script>");
                }
            }
            catch { }
        }
    }
}