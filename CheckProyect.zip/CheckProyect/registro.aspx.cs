﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using CheckProyect.BO;
using CheckProyect.DAO;

namespace CheckProyect
{
    public partial class registro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            LoginBO user = new LoginBO();
            LoginDAO userCtrl = new LoginDAO();
            user.usuario1 = txtusu.Text;
            user.password1 = txtcontra.Text;
            user.correo = txtcorreo.Text;
            user.Nombre = txtnombre.Text;
            try
            {
                int ban = userCtrl.UsuarioAdd(user);
                if (ban == 1) {
                    Response.Write("<script>window.alert('usuario registrado, puede iniciar sesssion');</script>");
                     Response.Redirect("Login.aspx?");
                }
                else {
                    Response.Write("<script>window.alert('No se pudo completar el registro');</script>");
                }

             

         
            }
            catch { }
        
        }
    }
}