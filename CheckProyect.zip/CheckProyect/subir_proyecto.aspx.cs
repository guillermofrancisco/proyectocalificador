﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;

using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using CheckProyect.CONTROL;
using System.Data;

namespace CheckProyect
{
    public partial class subir_proyecto : System.Web.UI.Page
    {
        string nombreUsu = "";
        string nombrecomple = "";
        int idusuario = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            idusuario = Convert.ToInt32(Session["s_idusuario"]);
            nombreUsu = Session["s_Nomusuario"].ToString();
            nombreUsu = " gracias por subir su proyecto";
            nombrecomple = nombreUsu + nombreUsu;
        }

        protected void subirpdf_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                try
                {
                    if (FileUpload1.PostedFile.ContentType != "")
                    {
                        string pdf = Path.GetFileName(FileUpload1.FileName);
                        string pdf2 = Path.GetFileName(FileUpload2.FileName);
                        FileUpload1.SaveAs(Server.MapPath("~/temp/") + pdf);
                        FileUpload2.SaveAs(Server.MapPath("~/temp/") + pdf);
                        string rutapdf = Server.MapPath("~/temp/" + pdf);
                        string rutapdf2 = Server.MapPath("~/temp/" + pdf);
                        string nombrepdf = Path.GetFileName(rutapdf);
                        string nombrepdf2 = Path.GetFileName(rutapdf2);
                        string droplist = DropDownList1.Text;
                        string nombre = txtnombre.Text;
                        string repre = txtrepre.Text;
                        string correo = txtcorreo.Text;
                        string documento = "documento";
                        string url = txturl.Text;
                        string comentario = txtcometario.Text;
                        if (CONTROL.AccesoLogica.insertarPDF(nombrepdf, rutapdf, droplist, nombre, repre, correo, url, comentario, documento, idusuario,nombrepdf2, rutapdf2))
                        {
                            lblstatus.Text = "Estado: Se ha almacenado el archivo correctamente";
                            lblstatus2.Text = "Estado: Se ha almacenado el archivo correctamente";
                            limpiar();
                            Response.Write("<script>window.alert('" + nombrecomple + "');</script>");
                            foreach (var f in Directory.GetFiles(Server.MapPath("~/temp/")))
                                File.Delete(f);
                        }
                        else
                            lblstatus.Text = "Estado: Error al intentar almacenar el archivo PDF";
                            lblstatus2.Text = "Estado: Error al intentar almacenar el archivo PDF";

                    }
                    else
                    {
                        lblstatus.Text = "Estado: Solo se aceptan archivos .PDF";
                        lblstatus2.Text = "Estado: Solo se aceptan archivos .PDF";
                    }
                }
                catch (Exception ex)
                {
                    lblstatus.Text = "Estado: El archivo se pudo almacenar," + ex.Message;
                    lblstatus2.Text = "Estado: El archivo se pudo almacenar," + ex.Message;
                }
            }
           
        }

        private void download(DataTable dt)
        {
            Byte[] bytes = (Byte[])dt.Rows[0]["Datos"];
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = dt.Rows[0]["Tipo"].ToString();
            Response.AddHeader("content-disposition", "attachment;filename=" + dt.Rows[0]["Nombre"].ToString());
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }

        public void limpiar()
        {
            txtcometario.Text = "";
            txtcometario.Text = "";
            txtcorreo.Text = "";
            txtnombre.Text = "";
            txtrepre.Text = "";
            txturl.Text = "";
            txtducomento2.Value = "";
        }
    }
}